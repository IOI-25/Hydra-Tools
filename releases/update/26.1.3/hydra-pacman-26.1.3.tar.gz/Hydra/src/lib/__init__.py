
from .readversion import main as readversion